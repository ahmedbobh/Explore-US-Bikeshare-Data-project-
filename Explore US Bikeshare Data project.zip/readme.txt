there is websites helped me in the project like:

1-https://www.codegrepper.com/code-examples/python/call+most+recent+value+of+array+in+pandas+dataframe

2-https://www.py4u.net/discuss/17392

3-https://www.geeksforgeeks.org/pandas-all-combinations-of-two-columns/

4-https://www.codegrepper.com/code-examples/python/find+the+most+frequent+word+in+string+column+dataframe

5-https://blog.finxter.com/how-to-ask-users-for-input-until-they-provide-a-valid-input/

i liked this project as it gave me more experiences in python

i used books:

1-how to handle pandas in python

2-basics of python
